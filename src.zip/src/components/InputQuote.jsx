import "./InputQuote.css"

const InputQuote = ({onSubmit}) => {
    return (

        <div style={{"display":"flex","justifyContent":"center","alignItems":"center","width":"50%"}}>
            <form onSubmit={onSubmit} style={{"border":"1px solid black",padding:"2rem","borderRadius":"20px"}}>
                <label>Quote:</label><br />
                <textarea name="quote" placeholder="Enter Quote"></textarea> <br /><br />
                <label>Author:</label><br />
                <input name="author" placeholder="Enter Author" /> <br /><br />
                <button>Submit</button>
            </form>
        </div>

    )
}

export default InputQuote;