const Quote  = ({content,author}) => {

    return(
        <div style={{backgroundColor:"black",color:"white",maxWidth:"300px","padding":"4rem","borderRadius":"10px",fontSize:"2rem","maxHeight":"200px","margin":"20px"}}>

            {/*  main content */ }
            <div style={{"textAlign":"center","marginBottom":"40px"}}>
                {content}
            </div>

            <hr color="yellow" width="70%" />

            {/*  author */ }
            <div style={{"textAlign":"center"}}>
                {author}
            </div>

        </div>
    )

}

export default Quote;