import Quote from "./Quote"

const QuoteList =({quotes}) => {
    return(
        <div style={{display:"flex",gap:"20px","borderRight":"1px solid black","width":"50%","overflow":"auto","margin":"0","flexDirection":"column"}}>
            {
                quotes.map((quote,index)=>
                    <Quote key={index} content={quote.quote} author={quote.author} />
                )
            }

        </div>
    )
}

export default QuoteList

