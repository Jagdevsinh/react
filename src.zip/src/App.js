import { useState } from 'react';
import './App.css';
import InputQuote from './components/InputQuote';
import QuoteList from './components/QuoteLIst';

function App() {

  const [quotes,setQuotes] = useState([]);

  const handleAddQuote = (e) => {
    e.preventDefault();

    const formData = new FormData(e.target);

    const quote = formData.get('quote')
    const author = formData.get('author')

    setQuotes([...quotes,{quote,author}])

  }

  return (
    <div style={{display:"flex",gap:"30px","width":"100%","height":"100vh"}}>
      <QuoteList quotes={quotes} /> 
      <InputQuote onSubmit={handleAddQuote} />
    </div>
  );
}

export default App;
