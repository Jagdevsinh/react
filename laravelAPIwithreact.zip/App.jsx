import IDCard from "./IDCard";


function App() {
  return (
    <>
      {/* <IDCard /> */}
      <IDCard />
    </>
  );
}

export default App;