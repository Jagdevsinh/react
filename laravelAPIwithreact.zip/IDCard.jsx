import React, { useState } from "react";
function IDCard() {
  const [profile, setProfile] = useState({});
  function handleChange(event) {
    setProfile({ ...profile, [event.target.name]: event.target.value });
  }

  async function dataSubmit(data) {
    console.log("Data:", data);
    const response = await fetch("http://localhost:8000/api/test", {
      method: "POST",
      body: JSON.stringify(data),
      headers: {
        "Content-Type": "application/json",
      },
    })
      .then((response) => {
        return response.json();
      })
      .then((rdata) => {
        console.log("Success:", rdata);
      })
      .catch((error) => {
        console.error("Error:", error);
      });
  }
  return (
    <div
      style={{
        display: "grid",
        gridTemplateColumns: "50% 50%",
        height: "92vh",
      }}
    >
      <div style={{ backgroundColor: "cream" }}>
        <p>Name</p>
        <input
          type="text"
          placeholder="Enter your First Name"
          onChange={(event) => {
            handleChange(event);
          }}
          name="firstName"
        />

        <input
          type="text"
          placeholder="Enter your Last Name"
          onChange={(event) => {
            handleChange(event);
          }}
          name="lastName"
        />

        <input
          type="text"
          placeholder="Enter your City"
          onChange={(event) => {
            handleChange(event);
          }}
          name="city"
        />

        <input
          type="number"
          placeholder="Enter your mobile Name"
          onChange={(event) => {
            handleChange(event);
          }}
          name="mobile"
        />

        <input
          type="email"
          placeholder="Enter your email Name"
          onChange={(event) => {
            handleChange(event);
          }}
          name="email"
        />

        <button
          onClick={() => {
            dataSubmit(profile);
          }}
        >
          Submit
        </button>
      </div>
      <div style={{ backgroundColor: "lightblue" }}>
        <center>
          <h1>Name: {`${profile.firstName} ${profile.lastName}`}</h1>
        </center>
      </div>
    </div>
  );
}
export default IDCard;