
import TeamList from "./TeamList";


function App() {
  return (
    <>
      {/* <IDCard /> */}
      <TeamList />
    </>
  );
}

export default App;