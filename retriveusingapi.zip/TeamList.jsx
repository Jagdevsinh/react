// src/components/TeamList.js
import React, { useEffect, useState } from "react";
import TeamMemberCard from "./TeamMemberCard"; // Import the card component


const TeamList = () => {
  const [sampleTeamData, setSampleTeamData] = useState([
    {
      firstName: "aaa",
      lastName: "bbb",
      city: "Rajkot",
      mobile: "0808798709",
      email: "aaa@gmail.com",
      id: 1,
    },
    {
        firstName: "bbb",
        lastName: "ccc",
        city: "Rajkot",
        mobile: "7856763856",
        email: "bbb@gmail.com",
        id: 2,
      },

      
    
  ]);

  useEffect(() => {
    fetch("http://localhost:8000/api/cards")
      .then((response) => response.json())
      .then((data) => {
        // console.log("Data fetched:", data);
        setSampleTeamData(data.data);
      })
      .catch((error) => {
        console.error("Error fetching data:", error);
      });
  }, []);

  return (
    <div className="team-list-container">
      {" "}
      <h2 className="team-main-title">XYZ</h2>{" "}
      {/* Use className */}
      {sampleTeamData.map((member) => (
        <TeamMemberCard key={member.id} member={member} />
      ))}
    </div>
  );
};

export default TeamList;