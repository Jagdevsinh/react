import React from "react";
import "./TeamStyles.css";

const TeamMemberCard = ({ member }) => {
  if (!member) {
    return null;
  }

  return (
    <div className="team-card">
      <img
        src={member.lastName}
        alt={`Profile of ${member.firstName}`}
        className="team-member-image"
      />
      <div className="team-text-content">
        <h3 className="team-member-name">{member.firstName}</h3>
        <h4 className="team-member-title">{member.city}</h4>
        <h4 className="team-member-title">{member.mobile}</h4>
        <h4 className="team-member-title">{member.email}</h4>
      </div>
    </div>
  );
};

export default TeamMemberCard;  