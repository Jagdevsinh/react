<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use DB;

class CardController extends Controller
{
    public function index(){

        $cards = DB::table('cards')->get();
        return response()->json([
            'code' => 200, 
            'message' => "Sucess", 
            'data' => $cards
        ]); 
    }

    public function show($id){

        $card = DB::table('cards')->where('id',$id)->first();
        return response()->json([
            'code' => 200, 
            'message' => "Sucess", 
            'data' => $card
        ]); 
    }


    public function store(Request $request) {
        DB::table('cards')->insert([
            'firstName' => $request->firstName, 
            'lastName' => $request->lastName,
            'city' => $request->city,
            'mobile' => $request->mobile,
            'email' => $request->email
        ]);
        return response()->json([
            'firstName' => $request->firstName, 
            'lastName' => $request->lastName,
            'city' => $request->city,
            'mobile' => $request->mobile,
            'email' => $request->email
        ]);    
    }
}