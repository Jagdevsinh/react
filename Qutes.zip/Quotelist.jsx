import React from 'react';
import Qutes from './Qutes';
const Quotelist = ({ quotes }) => {
 return (
 <div>
 {quotes.map((quote, index) => (
 <Qutes key={index} content={quote.quote} author={quote.author} />
 ))}
 </div>
 );
};
export default Quotelist;