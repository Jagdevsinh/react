import React from 'react';
const Qutes = ({ content, author }) => {
 return (
 <div style={{ border: '1px solid black', margin: '10px', padding: '10px' }}>
 <div><strong>Quote:</strong> {content}</div>
 <div><strong>Author:</strong> {author}</div>
 </div>
  );
};
export default Qutes;
