import React from 'react';

const InputQuote = ({ onsubmit }) => {
  return (
    <div>
      <form onSubmit={onsubmit}>
        <label>Quote</label><br />
        <textarea name="quote" placeholder="Enter quote" required></textarea><br /><br />
        <label>Author</label><br />
        <textarea name="author" placeholder="Enter author name" required></textarea><br /><br />
        <button type="submit">Submit</button>
      </form>
    </div>
  );
};

export default InputQuote;
