import { useState } from 'react';
import Quotelist from './Quotelist';
import InputQuote from './InputQuote';
function App() {
 const [quotes, setQuotes] = useState([]);

 const handleAddQuotes = (e) => {
  e.preventDefault();
  const formData = new FormData(e.target);
  const quote = formData.get('quote');
  const author = formData.get('author');
  setQuotes([...quotes, { quote, author }]);
  };
  return (
  <>
  <Quotelist quotes={quotes} />
  <InputQuote onsubmit={handleAddQuotes} />
  </>
  );
 }
 export default App;